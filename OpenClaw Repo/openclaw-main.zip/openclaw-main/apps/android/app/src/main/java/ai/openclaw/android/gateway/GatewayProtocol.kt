package ai.openclaw.android.gateway

const val GATEWAY_PROTOCOL_VERSION = 3
